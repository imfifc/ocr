#!/bin/bash

wget http://nexus.tianrang-inc.com/repository/assets/golang/protoc_linux64_3.6.1
wget http://nexus.tianrang-inc.com/repository/assets/golang/protoc-gen-go_linux64
