#!/bin/bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"
ASSETS_DIR=$(echo $ROOT/assets)

download() {
    remotepath="$1"
    nslashes=$(echo "${remotepath}" | tr -cd '/' | wc -c)
    wget -nv -nH --no-parent -r -e robots=off \
        --directory-prefix . \
        --cut-dirs=$((nslashes - 3)) \
        "${remotepath}" >&2 ||
        {
            ret=$?
            echo "cannot download file: ${remotepath}" >&2
            exit $ret
        }
}

echo "downloading yolo pretrained models"
mkdir -p ${ASSETS_DIR}/train/yolo/pre-trained-models
(
    cd ${ASSETS_DIR}/train/yolo/pre-trained-models
    download http://fs-tianshi.cloud.tianrang-inc.com/models/yolo/pre_trained/
)

echo "downloading detectron2 pretrained models"
mkdir -p ${ASSETS_DIR}/train/detectron2/pre-trained-models
(
    cd ${ASSETS_DIR}/train/detectron2/pre-trained-models
    download http://fs-tianshi.cloud.tianrang-inc.com/tianshi-models/detectron2/offical_pretrained_model/hrnet_origin_backbone/
    download http://fs-tianshi.cloud.tianrang-inc.com/tianshi-models/detectron2/offical_pretrained_model/backbone/
    download http://fs-tianshi.cloud.tianrang-inc.com/tianshi-models/detectron2/dbnet_all_data/
)

echo "downloading recognition ocr chars"
mkdir -p ${ASSETS_DIR}/train/recognition/charset
(
    cd ${ASSETS_DIR}/train/recognition/charset
    download http://fs-tianshi.cloud.tianrang-inc.com/models/ocr_chars/
)

echo "downloading yolo background images"
mkdir -p ${ASSETS_DIR}/train/yolo/bg
(
    cd ${ASSETS_DIR}/train/yolo/bg
    download http://fs-tianshi.cloud.tianrang-inc.com/models/ocr_bg/bg-2017-train/
    download http://fs-tianshi.cloud.tianrang-inc.com/models/ocr_bg/texture/
    mv bg-2017-train/* .
    mv texture/* .
    rm -r bg-2017-train
    rm -r texture
)

# clean all index.html files
(
    find ${ASSETS_DIR}/train -name index.htm\* -type f -delete
)
