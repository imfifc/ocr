#!/bin/bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"
DATA_DIR=$(grep ^DATA_DIR $ROOT/docker-compose/.env | cut -d = -f 2)
IMAGE=$(grep ^IMAGE_OCR_STRUCTURING_SERVICE docker-compose/.env | cut -d = -f 2)

echo extract ocr-structuring /opt from $IMAGE ...

docker run -v $DATA_DIR/opt:/mnt --rm -it $IMAGE bash -c "cp -r /opt/* /mnt"

echo complete extracting ocr-structuring /opt ...
