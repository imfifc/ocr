#!/bin/bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"
ASSETS_DIR=$(echo $ROOT/assets)

mkdir -p ${ASSETS_DIR}/licence
docker run -it --rm -v ${ASSETS_DIR}/licence:/mnt hub-docker-h.tianrang-inc.com/tianshi/licence:1.0.1-poc-build.2 bash -c "cp ./* /mnt"