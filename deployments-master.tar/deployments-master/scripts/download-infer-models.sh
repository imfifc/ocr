#!/bin/bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"
DATA_DIR=$(grep DATA_DIR $ROOT/docker-compose/.env | cut -d = -f 2)

download() {
    remotepath="$1"
    nslashes=$(echo "${remotepath}" | tr -cd '/' | wc -c)
    wget -nv -nH --no-parent -r -e robots=off \
        --directory-prefix . \
        --cut-dirs=$((nslashes - 3)) \
        "${remotepath}" >&2 ||
        {
            ret=$?
            echo "cannot download file: ${remotepath}" >&2
            exit $ret
        }
}

echo "downloading idcard models"
mkdir -p ${DATA_DIR}/infer/models/yolo/idcard
(
    cd ${DATA_DIR}/infer/models/yolo/idcard
    download http://fs-tianshi.cloud.tianrang-inc.com/models/yolo/idcard_2_classes/
)
mkdir -p ${DATA_DIR}/infer/models/orientation/idcard
(
    cd ${DATA_DIR}/infer/models/orientation/idcard
    download http://fs-tianshi.cloud.tianrang-inc.com/models/orientation/idcard/
)
mkdir -p ${DATA_DIR}/infer/models/detectron2/idcard
(
    cd ${DATA_DIR}/infer/models/detectron2/idcard
    curl -O http://fs-tianshi.cloud.tianrang-inc.com/models/detectron2/idcard_gv/config.yaml
    curl -O http://fs-tianshi.cloud.tianrang-inc.com/models/detectron2/idcard_gv/model_0044999_0.299027.pth
)
mkdir -p ${DATA_DIR}/infer/models/recognition/idcard
(
    cd ${DATA_DIR}/infer/models/recognition/idcard
    curl -O http://fs-tianshi.cloud.tianrang-inc.com/models/recognition/crnn/v2/final_words_v2.txt
    curl -O http://fs-tianshi.cloud.tianrang-inc.com/models/recognition/crnn/v2/step_415000_loss_0.7315.pth
)

# clean all index.html files
(
    find ${DATA_DIR}/infer/models -name index.htm\* -type f -delete
)
