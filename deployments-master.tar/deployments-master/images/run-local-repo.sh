#!/bin/bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
REGISTRY_IMAGE="registry:2"

if [ -f "${DIR}/IMAGE_REGISTRY.tar.gz" ]; then
    gzip -d -c IMAGE_REGISTRY.tar.gz | docker load
else
    docker save ${REGISTRY_IMAGE} | gzip -c > IMAGE_REGISTRY.tar.gz
fi

docker rm -f local-registry
docker run \
 -d \
 -p 5000:5000 \
 -v ${DIR}/data:/var/lib/registry \
 --restart always \
 --name local-registry \
 ${REGISTRY_IMAGE}
