#!/bin/bash

concurrency=8
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"

echo "pull images from repo"
for i in `cat $ROOT/docker-compose/.env | grep IMAGE`
do
    test "$(jobs | wc -l)" -ge $concurrency && wait -n || true
    {
        image_name=`echo $i | cut -d = -f 2-`
        name=`echo $image_name | cut -d / -f 2-`
        docker pull localhost:5000/$name
        docker tag localhost:5000/$name $image_name
    } &
done
wait
echo "pull images from repo finished"
