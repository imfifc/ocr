#!/bin/bash

concurrency=8
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"

echo "pull images"
for i in `cat $ROOT/docker-compose/.env | grep IMAGE`
do
    test "$(jobs | wc -l)" -ge $concurrency && wait -n || true
    {
        name=`echo $i | cut -d = -f 1 | cut -d _ -f 2-`
        image_name=`echo $i | cut -d = -f 2-`
        echo "pull $image_name"
        docker pull $image_name
    } &
done
wait
echo "pull images finished"
