#!/bin/bash

concurrency=8
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
ROOT="$(cd "$(dirname "$DIR")" >/dev/null 2>&1 && pwd)"

echo "push images"
for i in `cat $ROOT/docker-compose/.env | grep IMAGE`
do
    test "$(jobs | wc -l)" -ge $concurrency && wait -n || true
    {
        image_name=`echo $i | cut -d = -f 2-`
        name=`echo $image_name | cut -d / -f 2-`
        docker tag $image_name localhost:5000/$name
        docker push localhost:5000/$name
    } &
done
wait
echo "push images finished"
