ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'toor123';
CREATE DATABASE `media` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE `digital_platform` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE `data_gen` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE `structuring-tool` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;